﻿
using System;
using System.IO;
using Microsoft.VisualBasic.FileIO;



namespace easySave
{
    class CopyFile
    {

        public void Copy(string sourcePath, string destPath, string name)  
        {
            string fileName;
            string LogPath = "C:\\Users\\ASUS\\Desktop\\JOB\\LogFile.json";
            int nbrFile = 0;


            string[] filePaths = Directory.GetFiles(sourcePath);

            using (StreamWriter LogFile = System.IO.File.CreateText(LogPath))
            {
                foreach (string file in filePaths)
                {
                        nbrFile++;

                        fileName = Path.GetFileName(file);
                        string destFile = Path.Combine(destPath, fileName);
                        LogFile.WriteLine(" File Number :" + nbrFile);
                        LogFile.WriteLine(" File Name :" + fileName);
                        long length = new FileInfo(file).Length;
                        LogFile.WriteLine(" File length :" + length + "KB");
                        LogFile.WriteLine(" Last Access :" + File.GetLastAccessTime(file));
                        LogFile.WriteLine("-----------------------------------------\n");

                }
               
            }

            FileSystem.CopyDirectory(sourcePath, destPath, UIOption.AllDialogs);

        }

        public bool checkExistence(string path)   // Verify if file exists or not
        {
            if (File.Exists(path))
            {
                return true;
            }

            return false;
        }


    }
}
